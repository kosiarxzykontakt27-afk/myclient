package pl.myclient.module;

public enum Category {
	COMBAT, VISUALS, HUD
}
