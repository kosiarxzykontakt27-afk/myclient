package pl.myclient.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;
import pl.myclient.Config;
import pl.myclient.Waypoints;
import pl.myclient.module.Module;
import pl.myclient.module.ModuleManager;
import pl.myclient.setting.Setting;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ClickGuiScreen extends Screen {
	private static final float TS = 0.85f;
	private static final int DEF_W = 554, DEF_H = 330;

	private static final int[] HUE = {0, 30, 275, 220, 135};
	private static final String[] THEME_PL = {"Domy\u015blny", "Pomara\u0144czowy", "Fioletowy", "Niebieski", "Zielony"};
	private static final String[] THEME_EN = {"Default", "Orange", "Purple", "Blue", "Green"};


	// paleta (po zastosowaniu motywu)
	private int cOutline, cWin, cSide, cRow, cRowHover, cTabSel, cTabSelText, cText, cTextSoft, cMuted,
			cOrangeText, cAccent, cPillOff, cKnobOff, cKnobOn, cCloseBg, cLine;

	private enum Kind { TAB, SIDE_BTN, CLOSE, SEARCH, CARD, BIND, WAYPOINT, WP_DEL, BUTTON, SETTING, SCROLLBAR, LABEL }

	private record Row(int x, int y, int w, int h, Kind kind, Module module, Setting setting,
					   String label, String label2, boolean flag, Runnable left, Runnable right) {
		boolean contains(double mx, double my) {
			return mx >= x && mx < x + w && my >= y && my < y + h;
		}
	}

	private List<Row> rows = new ArrayList<>();
	private int tab = 0;
	private int scroll = 0;
	private int contentHeight = 0;
	private String search = "";
	private boolean searchFocused = false;
	private Module openModule = null;
	private Module binding = null;
	private Row dragRow = null;
	private String flashText = "";
	private long flashUntil = 0;

	public ClickGuiScreen() {
		super(Text.literal("Kazuma Client"));
		applyTheme();
	}

	private String t(String pl, String en) {
		return GuiSettings.lang == 0 ? pl : en;
	}

	// ---------- motyw ----------
	private static int rot(int rgb, float deg) {
		float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
		float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
		float h;
		if (d == 0) h = 0;
		else if (max == r) h = ((g - b) / d) % 6;
		else if (max == g) h = (b - r) / d + 2;
		else h = (r - g) / d + 4;
		h *= 60;
		if (h < 0) h += 360;
		float s = max == 0 ? 0 : d / max, v = max;
		h = (h + deg) % 360;
		if (h < 0) h += 360;
		float c = v * s, x = c * (1 - Math.abs((h / 60f) % 2 - 1)), m = v - c;
		float rr, gg, bb;
		switch ((int) (h / 60f) % 6) {
			case 0 -> { rr = c; gg = x; bb = 0; }
			case 1 -> { rr = x; gg = c; bb = 0; }
			case 2 -> { rr = 0; gg = c; bb = x; }
			case 3 -> { rr = 0; gg = x; bb = c; }
			case 4 -> { rr = x; gg = 0; bb = c; }
			default -> { rr = c; gg = 0; bb = x; }
		}
		return 0xFF000000 | ((int) ((rr + m) * 255 + 0.5f) << 16) | ((int) ((gg + m) * 255 + 0.5f) << 8)
				| (int) ((bb + m) * 255 + 0.5f);
	}

	private void applyTheme() {
		if (GuiSettings.theme < 0 || GuiSettings.theme >= HUE.length) GuiSettings.theme = 0;
		float d = HUE[GuiSettings.theme];
		cOutline = rot(0xFFE8383D, d);
		cWin = rot(0xFF1E0F11, d);
		cSide = rot(0xFF2B1215, d);
		cRow = rot(0xFF3A1A1E, d);
		cRowHover = rot(0xFF4A2227, d);
		cTabSel = rot(0xFFB3262E, d);
		cTabSelText = rot(0xFFFFD6D6, d);
		cText = rot(0xFFF5E6E6, d);
		cTextSoft = rot(0xFFE8CFCF, d);
		cMuted = rot(0xFFB89A9C, d);
		cOrangeText = rot(0xFFFF5A5F, d);
		cAccent = rot(0xFFFF4D4F, d);
		cPillOff = rot(0xFF5E3A3E, d);
		cKnobOff = rot(0xFFE8C4C4, d);
		cKnobOn = rot(0xFFFFE3E3, d);
		cCloseBg = rot(0xFF4D2227, d);
		cLine = rot(0xFFFF5252, d);
	}

	// ---------- rysowanie ----------
	private static void rfill(DrawContext c, int x1, int y1, int x2, int y2, int r, int color) {
		r = Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2));
		if (r <= 0) {
			c.fill(x1, y1, x2, y2, color);
			return;
		}
		for (int i = 0; i < r; i++) {
			double dy = r - i - 0.5;
			int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
			c.fill(x1 + inset, y1 + i, x2 - inset, y1 + i + 1, color);
			c.fill(x1 + inset, y2 - i - 1, x2 - inset, y2 - i, color);
		}
		c.fill(x1, y1 + r, x2, y2 - r, color);
	}

	private void txt(DrawContext c, String s, int x, int y, int color) {
		MatrixStack m = c.getMatrices();
		m.push();
		m.translate((float) x, (float) y, 0f);
		m.scale(TS, TS, 1f);
		c.drawText(this.textRenderer, styled(s), 0, 0, color, GuiSettings.shadow);
		m.pop();
	}

	private Text styled(String s) {
		Text base = Text.literal(s);
		return GuiSettings.bold ? Text.literal(s).formatted(Formatting.BOLD) : base;
	}

	private int tw(String s) {
		return (int) (this.textRenderer.getWidth(styled(s)) * TS);
	}

	private void txtC(DrawContext c, String s, int cx, int y, int color) {
		txt(c, s, cx - tw(s) / 2, y, color);
	}

	private int ty(int boxY, int boxH) {
		return boxY + (boxH - 7) / 2;
	}

	private String fit(String s, int maxPx) {
		if (tw(s) <= maxPx) return s;
		while (s.length() > 1 && tw(s + "...") > maxPx) s = s.substring(0, s.length() - 1);
		return s + "...";
	}

	private void toggle(DrawContext c, int x, int y, boolean on) {
		rfill(c, x, y, x + 22, y + 12, 6, on ? cAccent : cPillOff);
		int kx = on ? x + 22 - 2 - 8 : x + 2;
		rfill(c, kx, y + 2, kx + 8, y + 10, 4, on ? cKnobOn : cKnobOff);
	}

	private void chevron(DrawContext c, int cx, int cy, boolean right, int color) {
		for (int dy = -3; dy <= 3; dy++) {
			int off = Math.abs(dy);
			int x = right ? cx - off : cx + off;
			c.fill(x, cy + dy, x + 1, cy + dy + 1, color);
		}
	}

	// ---------- geometria ----------
	private int W() { return Math.min(DEF_W, this.width - 16); }
	private int H() { return Math.min(DEF_H, this.height - 16); }
	private int wx() { return (this.width - W()) / 2; }
	private int wy() { return (this.height - H()) / 2; }
	private int contentX() { return wx() + 103; }
	private int contentW() { return W() - 103 - 15; }

	private void add(Kind k, int x, int y, int w, int h, Module m, Setting s, String label, String label2,
					 boolean flag, Runnable left, Runnable right) {
		rows.add(new Row(x, y, w, h, k, m, s, label, label2, flag, left, right));
	}


	private String keyName(int key) {
		if (key < 0) return t("Brak", "None");
		try {
			return InputUtil.fromKeyCode(key, 0).getLocalizedText().getString();
		} catch (Exception e) {
			return "#" + key;
		}
	}

	private int clipTop() { return wy() + 46; }
	private int clipBottom() { return wy() + H() - 8; }
	private int viewH() { return clipBottom() - (wy() + 50); }

	private boolean inClip(double my) {
		return my >= clipTop() && my < clipBottom();
	}

	private static boolean isContent(Kind k) {
		return k == Kind.CARD || k == Kind.BIND || k == Kind.WAYPOINT || k == Kind.WP_DEL
				|| k == Kind.BUTTON || k == Kind.SETTING || k == Kind.LABEL;
	}

	private int maxScroll() {
		return Math.max(0, contentHeight - viewH());
	}

	private int thumbH(int trackH) {
		if (contentHeight <= viewH()) return trackH;
		return Math.max(14, (int) ((long) trackH * viewH() / contentHeight));
	}

	private int thumbY(int trackY, int trackH, int th) {
		int ms = maxScroll();
		if (ms == 0) return trackY;
		return trackY + (int) Math.round((trackH - th) * (double) scroll / ms);
	}

	private boolean clampScroll() {
		int old = scroll;
		scroll = Math.max(0, Math.min(maxScroll(), scroll));
		return old != scroll;
	}

	private void buildRows() {
		rows = new ArrayList<>();
		int W = W(), H = H(), wx = wx(), wy = wy();
		int cx = contentX(), cw = contentW();

		// zamknij
		add(Kind.CLOSE, wx + W - 27, wy + 14, 17, 17, null, null, "\u00d7", null, false, this::close, null);

		// zakladki
		String[] names = {t("Modu\u0142y", "Modules"), t("Znaczniki", "Waypoints"), t("Klawisze", "Binds")};
		for (int i = 0; i < 3; i++) {
			final int idx = i;
			add(Kind.TAB, wx + 8, wy + 58 + i * 26, 79, 23, null, null, names[i], null, tab == i, () -> {
				tab = idx;
				scroll = 0;
				openModule = null;
				binding = null;
			}, null);
		}

		// przyciski na dole paska
		String themeName = GuiSettings.lang == 0 ? THEME_PL[GuiSettings.theme] : THEME_EN[GuiSettings.theme];
		String[] bottomLabels = {
				GuiSettings.bold ? t("Font: gruba", "Font: bold") : t("Font: MC", "Font: MC"),
				t("Sekret", "Secret"),
				themeName,
				"PL / EN"
		};
		Runnable[] bottomActions = {
				() -> {
					GuiSettings.bold = !GuiSettings.bold;
					Config.save();
				},
				() -> {
					flashText = t("Nic tu nie ma... na razie.", "Nothing here... yet.");
					flashUntil = System.currentTimeMillis() + 3000;
				},
				() -> {
					GuiSettings.theme = (GuiSettings.theme + 1) % HUE.length;
					applyTheme();
					Config.save();
				},
				() -> {
					GuiSettings.lang = 1 - GuiSettings.lang;
					Config.save();
				}
		};
		for (int i = 0; i < 4; i++) {
			add(Kind.SIDE_BTN, wx + 8, wy + H - 93 + i * 21, 79, 18, null, null, bottomLabels[i], null, false,
					bottomActions[i], null);
		}

		// szukajka
		add(Kind.SEARCH, cx, wy + 10, cw - 19, 24, null, null, "", null, false, () -> searchFocused = true, null);

		int y0 = wy + 50 - scroll;
		int bottom = y0;
		String q = search.toLowerCase(Locale.ROOT);

		if (openModule != null) {
			add(Kind.BUTTON, cx, y0, cw, 24, null, null, "< " + t("Wstecz", "Back") + " (" + openModule.name + ")", null, false, () -> openModule = null, null);
			bottom = y0 + 24;
			int i = 0;
			for (Setting st : openModule.getSettings()) {
				int y = y0 + 30 + (i * 57) / 2;
				add(Kind.SETTING, cx, y, cw, 24, openModule, st, st.name, null, false, null, null);
				bottom = y + 24;
				i++;
			}
		} else if (tab == 1) {
			List<Waypoints.Point> pts = new ArrayList<>();
			for (Waypoints.Point p : Waypoints.all()) {
				if (q.isEmpty() || p.name().toLowerCase(Locale.ROOT).contains(q)) pts.add(p);
			}
			add(Kind.BUTTON, cx, y0, cw, 24, null, null,
					"+ " + t("Dodaj znacznik (Twoja pozycja)", "Add waypoint (your position)"), null, false, () -> {
						MinecraftClient mc = MinecraftClient.getInstance();
						if (mc.player == null) return;
						int n = Waypoints.all().size() + 1;
						Waypoints.add(new Waypoints.Point("Punkt " + n, (int) Math.floor(mc.player.getX()),
								(int) Math.floor(mc.player.getY()), (int) Math.floor(mc.player.getZ())));
						Config.save();
					}, null);
			bottom = y0 + 24;
			MinecraftClient mc = MinecraftClient.getInstance();
			for (int i = 0; i < pts.size(); i++) {
				Waypoints.Point p = pts.get(i);
				int y = y0 + ((i + 1) * 57) / 2;
				String dist = "";
				if (mc.player != null) {
					double dx = p.x() + 0.5 - mc.player.getX(), dy = p.y() - mc.player.getY(), dz = p.z() + 0.5 - mc.player.getZ();
					dist = (int) Math.sqrt(dx * dx + dy * dy + dz * dz) + " m";
				}
				add(Kind.WAYPOINT, cx, y, cw, 24, null, null, p.name() + "  (" + p.x() + ", " + p.y() + ", " + p.z() + ")",
						dist, false, null, null);
				add(Kind.WP_DEL, cx + cw - 22, y + 5, 16, 14, null, null, "\u00d7", null, false, () -> {
					Waypoints.remove(p);
					Config.save();
				}, null);
				bottom = y + 24;
			}
			if (pts.isEmpty()) {
				add(Kind.LABEL, cx + 2, y0 + 33, cw, 10, null, null, t("Brak znacznik\u00f3w.", "No waypoints."), null, false, null, null);
				bottom = y0 + 43;
			}
		} else {
			List<Module> mods = new ArrayList<>();
			for (Module m : ModuleManager.all()) {
				if (q.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(q)) mods.add(m);
			}
			int colW = (cw - 14) / 3;
			for (int i = 0; i < mods.size(); i++) {
				Module m = mods.get(i);
				int r = i / 3, c = i % 3;
				int x = cx + c * (colW + 7), y = y0 + (r * 57) / 2;
				if (tab == 0) {
					add(Kind.CARD, x, y, colW, 24, m, null, m.name, null, false, m::toggle,
							m.getSettings().isEmpty() ? null : () -> openModule = m);
				} else {
					add(Kind.BIND, x, y, colW, 24, m, null, m.name, null, binding == m, () -> binding = m, () -> {
						m.key = -1;
						Config.save();
					});
				}
				bottom = Math.max(bottom, y + 24);
			}
			if (mods.isEmpty()) {
				add(Kind.LABEL, cx + 2, y0 + 4, cw, 10, null, null, t("Brak wynik\u00f3w.", "No results."), null, false, null, null);
				bottom = y0 + 14;
			}
		}
		contentHeight = bottom - y0;

		// pionowy suwak przewijania (prawa krawedz)
		add(Kind.SCROLLBAR, wx + W - 12, clipTop(), 6, clipBottom() - clipTop(), null, null, "", null, false, null, null);
	}

	// ---------- render ----------
	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);
		buildRows();
		if (clampScroll()) buildRows();

		int W = W(), H = H(), wx = wx(), wy = wy();
		int cx = contentX(), cw = contentW();

		// okno z pomaranczowa ramka
		rfill(ctx, wx, wy, wx + W, wy + H, 12, cOutline);
		rfill(ctx, wx + 1, wy + 1, wx + W - 1, wy + H - 1, 11, cWin);
		// pasek boczny
		rfill(ctx, wx + 2, wy + 2, wx + 94, wy + H - 2, 10, cSide);
		txtC(ctx, "Kazuma Client", wx + 48, wy + 20, cOrangeText);

		// linia pod szukajka
		ctx.fill(cx, wy + 40, cx + cw, wy + 41, cLine);

		for (int pass = 0; pass < 2; pass++) {
			if (pass == 1) ctx.enableScissor(cx, clipTop(), cx + cw, clipBottom());
			for (Row row : rows) {
				if (isContent(row.kind()) != (pass == 1)) continue;
				boolean hover = row.contains(mouseX, mouseY) && (pass == 0 || inClip(mouseY));
				int x = row.x(), y = row.y(), w = row.w(), h = row.h();

			switch (row.kind()) {
				case CLOSE -> {
					rfill(ctx, x, y, x + w, y + h, 5, hover ? cRowHover : cCloseBg);
					txtC(ctx, row.label(), x + w / 2, ty(y, h), cText);
				}
				case TAB -> {
					rfill(ctx, x, y, x + w, y + h, 5, row.flag() ? cTabSel : (hover ? cRowHover : cRow));
					txtC(ctx, row.label(), x + w / 2, ty(y, h), row.flag() ? cTabSelText : cTextSoft);
				}
				case SIDE_BTN -> {
					rfill(ctx, x, y, x + w, y + h, 5, hover ? cRowHover : cRow);
					txtC(ctx, fit(row.label(), w - 6), x + w / 2, ty(y, h), cTextSoft);
				}
				case SEARCH -> {
					rfill(ctx, x, y, x + w, y + h, 6, cRow);
					String shown;
					if (search.isEmpty() && !searchFocused) {
						shown = System.currentTimeMillis() < flashUntil ? flashText : t("Szukaj modu\u0142\u00f3w...", "Search modules...");
					} else {
						shown = search;
						if (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0) shown += "_";
					}
					txt(ctx, fit(shown, w - 16), x + 8, ty(y, h), cTextSoft);
				}
				case CARD -> {
					rfill(ctx, x, y, x + w, y + h, 5, hover ? cRowHover : cRow);
					txt(ctx, fit(row.label(), w - 40), x + 7, ty(y, h), cText);
					toggle(ctx, x + w - 7 - 22, y + (h - 12) / 2, row.module().isEnabled());
				}
				case BIND -> {
					rfill(ctx, x, y, x + w, y + h, 5, hover ? cRowHover : cRow);
					txt(ctx, fit(row.label(), w - 62), x + 7, ty(y, h), cText);
					String k = row.flag() ? "..." : keyName(row.module().key);
					k = fit(k, 50);
					int bw = Math.max(24, tw(k) + 10);
					rfill(ctx, x + w - 6 - bw, y + 4, x + w - 6, y + h - 4, 4, row.flag() ? cAccent : cPillOff);
					txtC(ctx, k, x + w - 6 - bw / 2, ty(y, h), row.flag() ? cKnobOn : cText);
				}
				case WAYPOINT -> {
					rfill(ctx, x, y, x + w, y + h, 5, cRow);
					txt(ctx, fit(row.label(), w - 120), x + 7, ty(y, h), cText);
					if (row.label2() != null && !row.label2().isEmpty()) {
						txt(ctx, row.label2(), x + w - 28 - tw(row.label2()), ty(y, h), cMuted);
					}
				}
				case WP_DEL -> {
					rfill(ctx, x, y, x + w, y + h, 4, hover ? cAccent : cPillOff);
					txtC(ctx, row.label(), x + w / 2, ty(y, h), cText);
				}
				case BUTTON -> {
					rfill(ctx, x, y, x + w, y + h, 5, hover ? cRowHover : cRow);
					txtC(ctx, row.label(), x + w / 2, ty(y, h), cText);
				}
				case SCROLLBAR -> {
					rfill(ctx, x, y, x + w, y + h, 3, cRow);
					int th = thumbH(h);
					int thY = thumbY(y, h, th);
					boolean can = contentHeight > viewH();
					rfill(ctx, x, thY, x + w, thY + th, 3, can ? (dragRow != null && dragRow.kind() == Kind.SCROLLBAR ? cKnobOff : cAccent) : cPillOff);
				}
				case LABEL -> txt(ctx, row.label(), x, y, cTextSoft);
				case SETTING -> {
					if (row.setting() instanceof Setting.Bool b) {
						rfill(ctx, x, y, x + w, y + h, 5, hover ? cRowHover : cRow);
						txt(ctx, b.name, x + 7, ty(y, h), cText);
						toggle(ctx, x + w - 7 - 22, y + (h - 12) / 2, b.value);
					} else if (row.setting() instanceof Setting.Num n) {
						rfill(ctx, x, y, x + w, y + h, 5, cRow);
						double frac = (n.value - n.min) / (n.max - n.min);
						int fw = (int) (w * frac);
						if (fw > 0) rfill(ctx, x, y, x + fw, y + h, 5, cTabSel);
						String val = n.step >= 1 ? String.valueOf((int) n.value) : String.format(Locale.US, "%.2f", n.value);
						txt(ctx, n.name, x + 7, ty(y, h), cText);
						txt(ctx, val, x + w - 7 - tw(val), ty(y, h), cText);
					}
				}
			}
			}
			if (pass == 1) ctx.disableScissor();
		}
	}

	// ---------- mysz i klawiatura ----------
	private void applySlider(Row row, double mouseX, double mouseY) {
		if (row.kind() == Kind.SCROLLBAR) {
			int ms = maxScroll();
			if (ms > 0) {
				int th = thumbH(row.h());
				double f = (mouseY - row.y() - th / 2.0) / (row.h() - th);
				f = Math.max(0, Math.min(1, f));
				scroll = (int) Math.round(f * ms);
			}
			return;
		}
		if (row.setting() instanceof Setting.Num n) {
			double frac = (mouseX - row.x()) / row.w();
			frac = Math.max(0, Math.min(1, frac));
			n.set(n.min + frac * (n.max - n.min));
		}
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		buildRows();
		searchFocused = false;
		binding = null;
		for (int i = rows.size() - 1; i >= 0; i--) {
			Row row = rows.get(i);
			if (!row.contains(mouseX, mouseY)) continue;
			if (isContent(row.kind()) && !inClip(mouseY)) continue;

			if (row.kind() == Kind.SETTING) {
				if (button == 0) {
					if (row.setting() instanceof Setting.Bool b) {
						b.value = !b.value;
						Config.save();
					} else if (row.setting() instanceof Setting.Num) {
						dragRow = row;
						applySlider(row, mouseX, mouseY);
					}
				}
				return true;
			}
			if (row.kind() == Kind.SCROLLBAR) {
				if (button == 0) {
					dragRow = row;
					applySlider(row, mouseX, mouseY);
				}
				return true;
			}
			Runnable action = button == 0 ? row.left() : (button == 1 ? row.right() : null);
			if (action != null) {
				action.run();
				if (row.kind() == Kind.CARD && button == 0) Config.save();
			}
			return true;
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	@Override
	public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
		if (dragRow != null) {
			applySlider(dragRow, mouseX, mouseY);
			return true;
		}
		return super.mouseDragged(mouseX, mouseY, button, dx, dy);
	}

	@Override
	public boolean mouseReleased(double mouseX, double mouseY, int button) {
		if (dragRow != null) {
			dragRow = null;
			Config.save();
		}
		return super.mouseReleased(mouseX, mouseY, button);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		scroll -= (int) Math.round(verticalAmount * 14);
		clampScroll();
		return true;
	}

	@Override
	public boolean charTyped(char chr, int modifiers) {
		if (searchFocused && chr >= 32 && chr != 127 && search.length() < 24) {
			search += chr;
			scroll = 0;
			openModule = null;
			return true;
		}
		return super.charTyped(chr, modifiers);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (binding != null) {
			if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_BACKSPACE) binding.key = -1;
			else binding.key = keyCode;
			binding = null;
			Config.save();
			return true;
		}
		if (searchFocused) {
			if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
				if (!search.isEmpty()) search = search.substring(0, search.length() - 1);
				scroll = 0;
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
				searchFocused = false;
				return true;
			}
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		Config.save();
		super.close();
	}
}
